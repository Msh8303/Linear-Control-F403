phase = data.Data.phase;
magnitude = data.Data.magnitude;
omega = data.Data.omega;
magnitude_db = 20*log(magnitude)/log(10);