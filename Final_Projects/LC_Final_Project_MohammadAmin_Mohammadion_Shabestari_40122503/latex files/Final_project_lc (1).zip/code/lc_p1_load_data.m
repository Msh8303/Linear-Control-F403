%Loading Data
data = load ('Data.mat');