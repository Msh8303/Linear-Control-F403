figure;
rlocus(sys, linspace(0, 100, 1000));
title('K > 0');
figure;
rlocus(sys, linspace(0, -100, 1000));
title('K < 0');